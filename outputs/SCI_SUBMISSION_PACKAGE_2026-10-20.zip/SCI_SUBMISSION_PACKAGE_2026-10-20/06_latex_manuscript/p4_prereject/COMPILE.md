# Compile p4_prereject.tex

## Prerequisites
- Install [Tectonic](https://tectonic.net/) (recommended, single-binary):
  ```powershell
  winget install tactiq.Tectonic
  ```
- Or install MiKTeX: `winget install MiKTeX.MiKTeX`

## Compile commands
```powershell
cd outputs/SCI_SUBMISSION_PACKAGE_2026-10-20/06_latex_manuscript/p4_prereject
tectonic p4_prereject.tex
```
Or with pdflatex + bibtex:
```powershell
pdflatex p4_prereject.tex
bibtex p4_prereject
pdflatex p4_prereject.tex
pdflatex p4_prereject.tex
```

## Journal template swap
The current documentclass is `article` (generic). For target journals:

| Journal | Template file | Swap line |
|---|---|---|
| Frontiers in Computational Neuroscience | `frontiersin.cls` | `\documentclass[running]{frontiersin}` |
| Scientific Reports | `sn-jnl.cls` | `\documentclass[script,sn-nature]{sn-jnl}` |
| PLOS ONE | `plosone.cls` | `\documentclass[sn-nature]{sn-jnl}` |
| Neural Computation (MIT Press) | `mtp.cls` | `\documentclass[prelim]{mtp}` |

The template files are downloadable from each journal's author kit and should be
placed in this directory.

## Content checks
- Sections 1–7 (Introduction through Conclusion) are present.
- References resolve via `references.bib`; missing keys should log as warnings.
- All figures referenced in text are placeholders — add real PNGs/PDFs under
  `figures/` and update `\includegraphics` paths before submission.

## Data / Code availability
- Repository: https://github.com/lixing1123/flybrain-connectome
- License: MIT
- Pre-registration vault: `vault/` and `registry/preregistered_rejections.json`
